HtmlBox ver. 4.0.3
Copyright (c) 2007-2011 Remiya Solutions
Website: http://remiya.com

HtmlBox 4.0.3 is a Cross-browser interactive open-source
HTML textarea built on top of the jQuery library.
Tested with Mozilla Firefox, Inrernet Explorer, Opera,
Netscape, Chrome and Safari.

HtmlBox 4.0.3 is distributed under the MIT license
(included in the package). This means you can use it for
any purpose (even commercial) and include it in any
type of software.

A link back (credit) to the HtmlBox website will be
nice, but it is not obligatory in any way and is
subject to free will and desire to help its further
evolution.

For usage instructions on how to use this product see
the supplied demo's source code and look in the online
manual of HtmlBox at http://remiya.com.
