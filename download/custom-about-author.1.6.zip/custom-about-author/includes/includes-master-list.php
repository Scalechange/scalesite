<?php

/**
 * Master include list
 */

include_once(dirname(__FILE__).'/../config.php');
include_once(dirname(__FILE__).'/../database/database.php');
include_once(dirname(__FILE__).'/common.php');
include_once(dirname(__FILE__).'/../display-about-author-block.php');
