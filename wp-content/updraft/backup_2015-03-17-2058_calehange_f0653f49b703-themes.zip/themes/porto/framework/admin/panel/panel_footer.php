<!-- panel-footer -->
<div class="panel-footer">
    <input type="submit" value="<?php esc_attr_e( 'Reset All Options', 'spyropress' ); ?>" class="button-red pull-left reset-options"/>
	<input type="submit" value="<?php esc_attr_e( 'Save All Changes', 'spyropress' ); ?>" class="button-green pull-right save-options"/>
	<div class="clear"></div>
</div>
<!-- /panel-footer -->