<?php

$instance = spyropress_clean_array( $instance );

echo $this->query( $instance, '{content}' );