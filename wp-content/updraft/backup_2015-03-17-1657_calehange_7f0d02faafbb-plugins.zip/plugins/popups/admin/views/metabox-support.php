<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>

	<p><?php echo sprintf( __( 'You are using Popups plugin v%s', $this->plugin_slug ), SocialPopup::VERSION );?></p>
	<p><?php echo sprintf( __( 'If you need support please go to the WordPress.org <a href="%s">support forums</a>', $this->plugin_slug ), 'http://wordpress.org/support/plugin/http://wordpress.org/plugins/popups/');?></p>