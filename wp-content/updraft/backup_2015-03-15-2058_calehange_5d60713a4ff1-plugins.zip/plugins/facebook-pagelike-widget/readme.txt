=== Facebook Widget ===
Contributors: Milap 
Donate link:https://www.paypal.com/cgi-bin/webscr?business=cemilap.88@gmail.com&cmd=_xclick&currency_code=USD&amount=5&item_name=Offer%20me%20coffee
Tags: Facebook,Facebook like box,Facebook simple like, Facebook fan pages, Facebook like button, Facebook button share, Facebook Social bookmarking
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: trunk

This widget adds a Simple Facebook page Like Widget into your WordPress website sidebar.Also enabled short code for POST and PAGES.

== Description ==

This widget will provide you the most simple and attractive way to display facebook page likes into your wordpress sidebar. It is very easy to configure with admin area. You just need to acticate plugin and drag this widget like other widgets. Just add aplication id from your cerated facebook application, add it into widget and also URL of your facebook page. You also have other options like show faces , show Data Stream and Header.


In this second version, support to short code is added to display facebook like plugin into your post and pages.
Open your Post or Page, Add [fb_widget] into POst or Page, Save it. It's done.

Also added border color option for the widget.

Also i have managed code in a better way than previous version. :-)

Added support for localization (Multilanguage support)(Added .pot file)

Version 2.1
Added option to show or hide border from widget
Added default values to all needed fields while you setup widget, it will help you.

Version 2.2
Added option to add custom css for widget
Added option to select language to show your Facebook widget in any language you want.

I have tested my widget with following themes. Please let me know your theme name, if my widget also works with it.

1) Twenty Fourteen (http://wordpress.org/themes/twentyfourteen) <br />
2) Twenty Thirteen (http://wordpress.org/themes/twentythirteen) <br />
3) Twenty Twelve (http://wordpress.org/themes/twentytwelve) <br />
4) Twenty Eleven (http://wordpress.org/themes/twentyeleven) <br />
5) Avada (http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226) <br />

If you have any question regarding plugin, mail me on <a href=\"mailto:cemilap.88@gmail.com\">cemilap.88@gmail.com</a> or add me on <a href=\"http://www.facebook.com/milap112\">Milap</a>. I will reply you as soon as possible.

God bless you..!!

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

For more details,

<a href=\"http://codex.wordpress.org/Managing%5C\_Plugins\">http://codex.wordpress.org/Managing\_Plugins</a>
== Screenshots ==
1. See screenshot-1.jpeg explains how you can configure your plugin in admin widget area.

2. screenshot-2.jpeg shows how your plugin will display in frontend.